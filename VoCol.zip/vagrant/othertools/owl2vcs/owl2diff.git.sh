#!/bin/sh

owl2diff "$2" "$5"
